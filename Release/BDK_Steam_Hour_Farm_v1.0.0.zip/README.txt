========================================
  BDK Steam Hour Farm
========================================

Aplicacao para gerenciar jogos em idle na Steam.

ARQUIVOS INCLUIDOS:
-------------------
- BDKSteamHourFarm.exe       - Executavel principal (aplicacao principal)
- logo.ico                    - Icone da aplicacao
- steam-idle.exe              - Executavel auxiliar (simula jogos rodando)
- steam-idle.exe.config       - Configuracao do steam-idle
- steam_api64.dll             - DLL nativa da Steam API
- Steamworks.NET.dll          - DLL .NET da Steam API

REQUISITOS:
-----------
- Windows
- Steam instalado e rodando
- .NET Framework 4.8

COMO USAR:
----------
1. Certifique-se de que a Steam esta rodando
2. Execute BDKSteamHourFarm.exe
3. Digite os IDs dos jogos que deseja rodar (separados por virgula, espaco ou quebra de linha)
4. Clique em "Iniciar Jogos"
5. Para parar, clique em "Parar Jogos"

EXEMPLO:
--------
Digite: 730, 440, 570
Ou:
730
440
570

NOTAS:
------
- Todos os arquivos devem estar no mesmo diretorio
- Nao mova ou exclua nenhum arquivo
- O programa mostra o tempo de execucao de cada jogo
- Os jogos sao executados de forma oculta (minimizada)

POR QUE TANTO ARQUIVOS?
-----------------------
Este programa nao pode ser distribuido como um unico arquivo EXE porque:

1. steam-idle.exe: Processo separado necessario para simular cada jogo
2. steam_api64.dll: DLL nativa da Steam (nao pode ser embeddada)
3. Steamworks.NET.dll: DLL .NET com dependencias nativas
4. steam-idle.exe.config: Configuracao necessaria para o .NET Framework
5. logo.ico: Icone personalizado da aplicacao

========================================